#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <nrutil.h>
#include <nr2.h>
#include <stdlib.h>


#include "dcp_ft.h"

#define log2(x) log(x)/log(2.0)

/* ----------------------------- stim_fband() ------------------------------- */
stim_fband(pstim, nband, len, twindow, pow_level, f_low, f_high, f_width)
DCP_STIM *pstim;
int *nband;
int *len;
int twindow;             /* window of silence to add to stimulus on both sides in ms */
double ***pow_level;
float *f_low;
float *f_high;
float *f_width;
{
int i, j, nb, c_n;
int nframes, nbands;
int istart, nwindow;
int i_low, i_high;
double n_step;
double *pr;
float *c_song, *c_temp;
double f2, fres, df;
double expval;
double x, y, tstep;
double fstep, fval, fmean, i_val;
double a_val, a_low, a_high;
char fname[128];
FILE *f_save;

   /* Allocate memory for amplitude enveloppes */

	nframes = pstim->length;            /* Length of stim in points */
	*nband = nbands = ((*f_high)-(*f_low))/(*f_width);  /* Number of frequency bands */
	tstep = 1000.0/pstim->samprate;
	*len = (int)ceil(nframes*tstep);   /* Length of stim in ms */

	if ( tstep > 1.0 ) 
	{
		 printf("Error: Sampling rate is too low\n");
		 exit(1);
	}
	*pow_level = (double **)calloc(nbands+1, sizeof(double *) );
	for ( nb = -1; ++nb <= nbands; ) (*pow_level)[nb] = (double *)calloc(*len+2*twindow, sizeof(double));

	/* Allocate memory for complex array */
	nwindow = (int)ceil(twindow/tstep);
	c_n = (int)(log2((double)(nframes+2*nwindow))+0.5);
	c_n = (int)(pow(2.0,(double)c_n)+0.1);
	if ( c_n < (nframes+2*nwindow) ) c_n *=2;
	fres = ((float)pstim->samprate)/c_n;
   istart = (c_n-nframes)/2;
	printf("c_n = %d istart = %d nframes = %d nwindow=%d\n", c_n, istart, nframes, nwindow);

   c_song = (float *)calloc(c_n*2, sizeof(float));
	c_temp = (float *)calloc(c_n*2, sizeof(float));

	/* Stuff complex array */
	for ( i = -1; ++i < nframes; ) c_song[2*(i+istart)] = pstim->stimulus[i];

	/* Go to the fourier domain and zero out negative freqs */
	four1(c_song-1, (unsigned long)c_n, (int)1);

	for ( i = c_n; ++i < 2*c_n; ) c_song[i] = 0.0;

	/* Calculate analytical signal for each band */
	fres = ((float)pstim->samprate)/c_n;
	fstep = (*f_high-*f_low)/nbands;
	*f_width = fstep;
	f2=fstep*fstep;
	printf ("New frequency step: low = %g high = %g step=%g\n", *f_low, *f_high, *f_width);

	for ( nb = -1; ++nb < nbands; )
	{
		bcopy(c_song, c_temp, sizeof(float)*c_n*2);
		fmean = *f_low + (nb+0.5)*(fstep);
		
		for ( i = -1; ++i <= c_n/2; )
		{
			fval = i*fres;
			df = fval - fmean;
			expval = -0.5*df*df/f2;
			if ( expval > -10 )
			{
				expval = exp(expval);
				c_temp[2*i] *= expval;
				c_temp[2*i+1] *= expval;
			}
			else
			{
				c_temp[2*i] = 0.0;
				c_temp[2*i+1] = 0.0;
			}
		}
		four1(c_temp-1, (unsigned long)c_n, (int)-1);

		/* Stuff Amplitude */
		for ( j = -1; ++j < *len + 2*twindow; )
		{
			i_val = (j-twindow)/tstep;
			i_low = (int)floor(i_val) + istart;
			i_high = (int)ceil(i_val) + istart;
			i_val += istart;

			x = c_temp[2*i_low];
			y = c_temp[2*i_low+1];
			a_low = x*x + y*y;
			a_val = (1.0+i_low-i_val)*a_low;

			if (i_low != i_high)
			{
				x = c_temp[2*i_high];
				y = c_temp[2*i_high+1];
				a_high = x*x + y*y;
				a_val += (1.0+i_val-i_high)*a_high;
			}

			(*pow_level)[nb][j] = sqrt(a_val);
			(*pow_level)[nbands][j] += sqrt(a_val); 
		}
	}
	free(c_temp);
	free(c_song);
}
